# Telegram Expense Bot

Простой Telegram-бот для учета расходов с хранением данных в PostgreSQL.

## Что положить в репозиторий
- `bot.py`
- `requirements.txt`
- `.gitignore`
- `README.md`

## Какие переменные нужны в Railway
- `BOT_TOKEN` — токен Telegram-бота
- `DATABASE_URL` — строка подключения к PostgreSQL
- `ALLOWED_USER_IDS` — список Telegram user id через запятую, например `12345,67890`
- `TZ` — например `Europe/Moscow` (необязательно)

## Локальный запуск
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export BOT_TOKEN="..."
export DATABASE_URL="..."
export ALLOWED_USER_IDS="123456789"
python bot.py
```

## Railway
1. Создай сервис с этим кодом.
2. Добавь переменные `BOT_TOKEN`, `DATABASE_URL`, `ALLOWED_USER_IDS`.
3. Для базы используй рабочий PostgreSQL URL.
4. Команда запуска: `python bot.py`

## GitHub
```bash
git init
git add .
git commit -m "Initial working version"
git branch -M main
git remote add origin https://github.com/USERNAME/telegram-expense-bot.git
git push -u origin main
```

## Важно
Не загружай в GitHub реальные токены, пароли и `.env`.
